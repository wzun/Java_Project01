
package Java_Final_Project;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTableDB extends ConnectSqlite{
    
    public static void CreateTableDB(){
        try{
            Connection conn =connect();
            Statement statement = conn.createStatement();
            
            statement.execute("create table if not exists Basic_Hamburger "
                    + "(add_tomato Integer, add_lettuce Integer, add_carrot Integer, add_cheese Integer,B_Id Integer primary key)");
            
            statement.execute("create table if not exists Health_Hamburger "
                    + "(add_tomato Integer, add_lettuce Integer, add_carrot Integer, add_cheese Integer ,"
                    + "add_egg Integer, add_lentils Integer ,H_Id Integer primary key )");
            
            statement.execute("create table if not exists Deluxe_Hamburger "
                    + "(add_chips Integer, add_drink Integer, D_Id Integer primary key)");
            
            statement.execute("create table if not exists Hamburger_Sell_Record "
                    + "(OrderId Integer primary key, Hamburger_Type Text, Description Text, Base_Price Real,"
                    + "Addition_Detail Text, Final_Price Real )");
            
            System.out.println("Table create successfully!");
            statement.close();            
            conn.close(); 
            }
        catch (SQLException e) {
            System.out.println(" Error: " + e.getMessage());
        }
    }
}
