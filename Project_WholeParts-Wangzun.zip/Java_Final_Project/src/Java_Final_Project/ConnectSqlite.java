
package Java_Final_Project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectSqlite {
    
    public static Connection connect(){        
        Connection conn = null;
        try{  
            String url = "jdbc:sqlite: Java_Final_project_DB.db ";
            conn = DriverManager.getConnection(url);
            //System.out.println("Connected database successfully!");             
        }
        catch(SQLException e){
            System.out.println(e.getMessage());
        }
        return conn;
    }
}
