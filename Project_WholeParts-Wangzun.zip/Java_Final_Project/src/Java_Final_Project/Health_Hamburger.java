
package Java_Final_Project;

import java.util.Scanner;

public class Health_Hamburger extends Basic_Hamburger {
    
    double egg_price = 5.43;
    double lentils_price = 3.41 ;
    
    public Health_Hamburger(String bread_roll_type, String meat_type,double price) {
        super(bread_roll_type, meat_type,price);        
    }   
// function for choose health hamburger addition  
    public static int[] choseHealthAddition(){
            int [] addition = new int[6];
            int i ;
            int counter=0;
            System.out.println("Please choose Health Hamburger addition by input(0-5),'-1'to exit:");
            Scanner s = new Scanner(System.in);
            
            do{            
                System.out.println("0.->Tomato, 1.->Lettuce ,2.->carrot 3.->cheese, 4.->Egg, 5.->lentils, -1.->Exit");
                i = s.nextInt();
                if (i>=0 && i<6){
                    addition[i] += 1;
                }
                else if(i != -1){
                    System.out.printf("Error!please input number (0-5)for choose addition,'-1'to exit! \n");
                }
                counter += 1;                
            }while (i >= 0 && counter <6);
            return addition;
        }
    
    @Override
     public double CalculatePrice(double price,int[] addition){
        double total = price;
        for (int i=0;i<addition.length;i++){
            if (addition[i]>0){
                switch(i){
                    case 0:
                        total += add_tomato * addition[i];
                        System.out.printf("add tomato %d times,total price + %.2f \n", addition[i] ,add_tomato * addition[i]);
                        break;                       
                    case 1:
                        total += add_lettuce * addition[i]; 
                        System.out.printf("add lettuce %d times,total price + %.2f \n", addition[i] ,add_lettuce * addition[i]);
                        break;
                    case 2:
                        total += add_carrot * addition[i];
                        System.out.printf("add carrot %d times,total price + %.2f \n", addition[i] ,add_carrot * addition[i]);
                        break;
                    case 3:
                        total += add_cheese * addition[i];
                        System.out.printf("add cheese %d times,total price + %.2f \n", addition[i] ,add_cheese * addition[i]);
                        break;
                    case 4:
                        total += egg_price * addition[i];
                        System.out.printf("add egg %d times,total price + %.2f \n", addition[i] ,egg_price * addition[i]);
                        break;                       
                    case 5:
                        total += lentils_price * addition[i];
                        System.out.printf("add lentils %d times,total price + %.2f \n", addition[i] ,lentils_price * addition[i]);
                }
            }
        }
        return total;
    }
}
