
package Java_Final_Project;

import java.util.Scanner;

public class Deluxe_Hamburger extends Basic_Hamburger{
    
    double chips_price = 2.75 ;
    double drink_price = 1.81;
    
    public Deluxe_Hamburger(String bread_roll_type, String meat_type,double price) {
        super(bread_roll_type, meat_type,price);        
    }  
    // function for choose deluxe hamburger addition  
    public static int[] choseDeluxeAddition(){
            int [] addition = new int[2];
            int i ;
            System.out.println("Please choose Deluxe Hamburger addition by input(0,1),'-1'to exit:");
            Scanner s = new Scanner(System.in);
            do{            
                System.out.println("0.->chips, 1.->drink, -1.->Exit");
                i = s.nextInt();
                if (i>=0 && i<2){
                    addition[i] += 1;
                }
                else if(i != -1){
                    System.out.printf("Error!please input number (0-1)for choose addition,'-1'to exit! \n");
                }
            }while (i >= 0);
            return addition;
        }    
    @Override
    public double CalculatePrice(double price,int[] addition){
        double total = price;
        for (int i=0;i<addition.length;i++){
            if (addition[i]>0){                
                switch(i){
                    case 0:
                        total += chips_price * addition[i];
                        System.out.printf("add chips %d times,total price + %.2f \n", addition[i] ,chips_price * addition[i]);
                        break;                       
                    case 1:
                        total += drink_price * addition[i];
                        System.out.printf("add drink %d times,total price + %.2f \n", addition[i] ,drink_price * addition[i]);
                }
            }
        }
        return total;
    }
}
