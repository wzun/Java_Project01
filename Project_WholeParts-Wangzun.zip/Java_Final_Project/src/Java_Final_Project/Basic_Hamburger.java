
package Java_Final_Project;

import java.util.Scanner;

public class Basic_Hamburger  {
    
    String bread_roll_type;
    String meat_type;
    double price;
    
    double add_tomato =  0.27;
    double add_lettuce = 0.75; 
    double add_carrot = 0.85;
    double add_cheese = 1.13;
            
    public Basic_Hamburger(String bread_roll_type,String meat_type,double price){
        this.bread_roll_type = bread_roll_type;
        this.meat_type = meat_type;
        this.price = price;
    }   
// function for choose basic hamburger addition  
    public static int[] choseBasicAddition(){
            int [] addition = new int[4];   
            int i;
            int counter=0;
            System.out.println("Please choose Basic Hamburger addition by input(0,1,2,3),'-1'to exit:");
            Scanner s = new Scanner(System.in);
            
            do{                
                System.out.println("0.->Tomato, 1.->Lettuce ,2.->carrot 3.->cheese, -1.->Exit");
                i = s.nextInt();
                
                if (i>=0 && i<4){
                    addition[i] += 1;
                }
                else if(i != -1 ){
                    System.out.printf("Error!please input number (0-3)for choose addition, '-1'to exit ! \n");
                }
                counter += 1;
            }while (i >= 0 && counter <4);
            return addition;
        }
    
    public double CalculatePrice(double price,int[] addition){
        double total = price;
        for (int i=0;i<addition.length;i++){
            if (addition[i]>0){                
                switch(i){
                    case 0:
                        total += add_tomato * addition[i];
                        System.out.printf("add tomato %d times,total price + %.2f \n", addition[i] ,add_tomato * addition[i]);
                        break;                       
                    case 1:
                        total += add_lettuce * addition[i]; 
                        System.out.printf("add lettuce %d times,total price + %.2f \n", addition[i] ,add_lettuce * addition[i]);
                        break;
                    case 2:
                        total += add_carrot * addition[i];
                        System.out.printf("add carrot %d times,total price + %.2f \n", addition[i] ,add_carrot * addition[i]);
                        break;
                    case 3:
                        total += add_cheese * addition[i];
                        System.out.printf("add cheese %d times,total price + %.2f \n", addition[i] ,add_cheese * addition[i]);
                }
            }
        }
        return total;
    }
}
