
package Java_Final_Project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InputDataToDB extends CreateTableDB {

//function insert into database Basic_Hamburger       
    public static String InputToBasic(int[] BasicA){
            
        String A_Detail =null;
        try{               
             Connection conn =connect();             
             String sql = "insert into Basic_Hamburger(add_tomato , add_lettuce , add_carrot , add_cheese )"
                            + " values(?,?,?,?) ";
             PreparedStatement prep = conn.prepareStatement(sql);
                    prep.setInt(1, BasicA[0]);
                    prep.setInt(2, BasicA[1]);
                    prep.setInt(3, BasicA[2]);
                    prep.setInt(4, BasicA[3]);
                    prep.addBatch();

            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.commit();
            conn.setAutoCommit(true);
            
            System.out.println("insert into Basic_Hamburger successfully!");
            A_Detail= "add_tomato:"+ BasicA[0] +" ,add_lettuce: "+ BasicA[1] +",add_carrot:"+ BasicA[2] +",add_cheese:"+ BasicA[3];
            prep.close();            
            conn.close(); 
        }   
        catch (SQLException e) {
            System.out.println(" Error: " + e.getMessage());
        }
        return A_Detail;
    }
//function insert into database Health_Hamburger     
    public static String InputToHealth(int[] HealthA){
        
        String A_Detail =null;
        try{  
             Connection conn =connect();             
             String sql = "insert into Health_Hamburger(add_tomato , add_lettuce , add_carrot , add_cheese ,"
                     + "add_egg, add_lentils) values(?,?,?,?,?,?) ";
             PreparedStatement prep = conn.prepareStatement(sql);
                    prep.setInt(1, HealthA[0]);
                    prep.setInt(2, HealthA[1]);
                    prep.setInt(3, HealthA[2]);
                    prep.setInt(4, HealthA[3]);
                    prep.setInt(5, HealthA[4]);
                    prep.setInt(6, HealthA[5]);
                    prep.addBatch();

            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.commit();
            conn.setAutoCommit(true);
            
            System.out.println("insert into Health_Hamburger successfully!");
            A_Detail= "add_tomato:"+ HealthA[0] +" ,add_lettuce: "+ HealthA[1] +",add_carrot:"+ HealthA[2] 
                    +",add_cheese:"+ HealthA[3]+" ,add_egg: "+ HealthA[4] +",add_lentils:"+ HealthA[5];
            prep.close();            
            conn.close(); 
        }   
        catch (SQLException e) {
            System.out.println(" Error: " + e.getMessage());
        }
        return A_Detail;
    }
//function insert into database Deluxe_Hamburger       
    public static String InputToDeluxe(int[] DeluxeA){
        
        String A_Detail =null;
        try{  
             Connection conn =connect();             
             String sql = "insert into Deluxe_Hamburger(add_chips ,add_drink) values(?,?) ";
             PreparedStatement prep = conn.prepareStatement(sql);
                    prep.setInt(1, DeluxeA[0]);
                    prep.setInt(2, DeluxeA[1]);
                    prep.addBatch();

            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.commit();
            conn.setAutoCommit(true);
            
            System.out.println("insert into Deluxe_Hamburger successfully!");
            A_Detail= "add_chips:"+ DeluxeA[0] +" ,add_drink: "+ DeluxeA[1] ;
            prep.close();            
            conn.close(); 
        }   
        catch (SQLException e) {
            System.out.println(" Error: " + e.getMessage());
        }
        return A_Detail;
    }
    
//function insert into database Hamburger_Sell_Record     
    public static void InputToRecord(String HamburgerType ,String Bread_Meat, Double Base_Price , String A_Detail, Double Total_Price){
        try{  
             Connection conn =connect();             
             String sql = "insert into Hamburger_Sell_Record (Hamburger_Type, Description, Base_Price,"
                     + "Addition_Detail, Final_Price) values(?,?,?,?,?) ";  
             PreparedStatement prep = conn.prepareStatement(sql);
                    prep.setString(1, HamburgerType);
                    prep.setString(2, Bread_Meat);
                    prep.setDouble(3, Base_Price);
                    prep.setString(4, A_Detail);
                    prep.setDouble(5, Total_Price);
                    prep.addBatch();

            conn.setAutoCommit(false);
            prep.executeBatch();
            conn.commit();
            conn.setAutoCommit(true);
            
            System.out.println("insert into Hamburger_Sell_Record successfully!");
            prep.close();            
            conn.close(); 
        }   
        catch (SQLException e) {
            System.out.println(" Error: " + e.getMessage());
        }
    }
}
