
package Java_Final_Project;

import java.util.Scanner;

public class Hamburger_Menu extends InputDataToDB{
    
    public static void main(String [] args){

//create database tables       
        CreateTableDB();
//get the choose from user
        String Menu = choseHamburger();       
//----------------------------------------------------------------------------------------               
        switch (Menu){
          case ("Basic"):
//basic Hamburger only 
        Basic_Hamburger hamburger1 = new  Basic_Hamburger("White roll","Sausage",3.56);
        
        System.out.printf("%s on a %s with %s, base price is %.2f \n",Menu,
                hamburger1.bread_roll_type,hamburger1.meat_type,hamburger1.price);       
// basic Hamburger with additions                
        System.out.printf("Added Tomato for an extra %.2f \n",hamburger1.add_tomato);
        System.out.printf("Added Lettuce for an extra %.2f \n",hamburger1.add_lettuce);
        System.out.printf("Added Carrot for an extra %.2f \n",hamburger1.add_carrot);
        System.out.printf("Added Cheese for an extra %.2f \n",hamburger1.add_cheese);       
// calculate total price with addition        
        int[] B_addition = Basic_Hamburger.choseBasicAddition();         
        double B_Total = hamburger1.CalculatePrice(hamburger1.price, B_addition);

//insert into Database Basic_Hamburger and Hamburger_Sell_Record
        InputToRecord( Menu,"White roll,Sausage" , 3.56 ,InputToBasic(B_addition), B_Total);
        
        System.out.printf("Total %s with addition price is %.2f \n\n",Menu,B_Total);
        break;     
//----------------------------------------------------------------------------------------      
        case ("Health"):
// Health Hamburger with additions
        Health_Hamburger hamburger2 = new  Health_Hamburger("Brown rye roll","Bacon",5.67);   

        System.out.printf("Health hamburger on a %s with %s, base price is %.2f \n",
                hamburger2.bread_roll_type,hamburger2.meat_type,hamburger2.price);
        
        System.out.printf("Added Tomato for an extra %.2f \n",hamburger2.add_tomato);
        System.out.printf("Added Lettuce for an extra %.2f \n",hamburger2.add_lettuce);
        System.out.printf("Added Carrot for an extra %.2f \n",hamburger2.add_carrot);
        System.out.printf("Added Cheese for an extra %.2f \n",hamburger2.add_cheese);
        
        System.out.printf("Added Egg for an extra %.2f \n", hamburger2.egg_price);
        System.out.printf("Added Lentils for an extra %.2f \n" , hamburger2.lentils_price);
// calculate total price with addition        
        int[] H_addition = Health_Hamburger.choseHealthAddition();
        double H_Total = hamburger2.CalculatePrice(hamburger2.price, H_addition);

//insert into Database Health_Hamburger and Hamburger_Sell_Record      
        InputToRecord( Menu,"Brown rye roll,Bacon" , 5.67 ,InputToHealth(H_addition), H_Total);
        
        System.out.printf("Total Health Burger price is %.2f \n\n",H_Total);  
        break;
//----------------------------------------------------------------------------------------
        case("Deluxe"):
          
        System.out.printf("deluxe burger can not add additional items ,it served with chips and drink! \n");
//deluxe Hamburger with additions
        Deluxe_Hamburger hamburger3 = new  Deluxe_Hamburger("White roll","Sausage & Bacon",14.54);      

        System.out.printf("Deluxe hamburger on a %s with %s, base price is %.2f \n",
                hamburger3.bread_roll_type,hamburger3.meat_type,hamburger3.price);
        System.out.printf("Added chips for an extra %.2f \n", hamburger3.chips_price);
        System.out.printf("Added drink for an extra %.2f \n" , hamburger3.drink_price);
// calculate total price with addition        
        int[] D_addition = Deluxe_Hamburger.choseDeluxeAddition();
        double D_Total = hamburger3.CalculatePrice(hamburger3.price, D_addition);

//insert into Database Deluxe_Hamburger and Hamburger_Sell_Record      
        InputToRecord( Menu,"White roll,Sausage & Bacon" , 14.54 ,InputToDeluxe(D_addition), D_Total);
        
        System.out.printf("Total Deluxe Burger price is %.2f \n\n",D_Total);                  
      }  
}
//------------------------------------------------------------------------------------------------------
// function for choose hamburger    
    public static String choseHamburger(){
        String HamburgerName = "";
        int i;
        Scanner s = new Scanner(System.in);
        
        System.out.println("Please choose the Hamburger by input(0,1,2),'-1'to exit:");
        System.out.println("0.->Basic Hamburger,1.->Health Hamburger,2.->Deluxe hamburger, -1.->Exit");
            i = s.nextInt();
              if (i>=0 && i<3){
                switch(i){
                    case 0:
                        HamburgerName = "Basic";  
                        System.out.printf("You choose Basic_Hamburger,see menu below : \n");
                        break;                       
                    case 1:
                        HamburgerName = "Health"; 
                        System.out.printf("You choose Health_Hamburger,see menu below : \n");
                        break;
                    case 2:
                        HamburgerName = "Deluxe"; 
                        System.out.printf("You choose Deluxe_Hamburger,see menu below : \n");
                }
             }
                else if(i != -1){
                    System.out.println("Error!please input number (0-2)for choose your Hamburger!");
                    System.out.println();
                }
                else{
                    System.out.println("See you next time !");
                }
            return HamburgerName;
    }
}
